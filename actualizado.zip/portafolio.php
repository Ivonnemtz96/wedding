<!DOCTYPE html>
<html lang="es">
<?php
    include("includes/head.php");
?>

<body>
    <div class="page-wrapper">


        <?php
        include("includes/preloader.php");
        include("includes/header.php");
        include("modules/portafolio.php");
        include("includes/footer.php");
?>

    </div>
    <?
        include("includes/scripts.php");
    ?>

</body>

</html>