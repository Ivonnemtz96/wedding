<!-- start preloader -->
<div class="preloader">
    <div class="middle">
        <i class="fi flaticon-favorite-heart-button"></i>
        <i class="fi flaticon-favorite-heart-button"></i>
        <i class="fi flaticon-favorite-heart-button"></i>
        <i class="fi flaticon-favorite-heart-button"></i>
    </div>
</div>
<!-- end preloader -->