    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="author" content="irstheme">

        <title> Weddings at Cabo </title>
        <link rel="shortcut icon" href="/assets/images/favicon.png" type="image/x-icon">

        <link href="/assets/css/themify-icons.css" rel="stylesheet">
        <link href="/assets/css/flaticon.css" rel="stylesheet">
        <link href="/assets/css/bootstrap.min.css" rel="stylesheet">
        <link href="/assets/css/animate.css" rel="stylesheet">
        <link href="/assets/css/owl.carousel.css" rel="stylesheet">
        <link href="/assets/css/owl.theme.css" rel="stylesheet">
        <link href="/assets/css/slick.css" rel="stylesheet">
        <link href="/assets/css/slick-theme.css" rel="stylesheet">
        <link href="/assets/css/swiper.min.css" rel="stylesheet">
        <link href="/assets/css/owl.transitions.css" rel="stylesheet">
        <link href="/assets/css/jquery.fancybox.css" rel="stylesheet">
        <link href="/assets/css/magnific-popup.css" rel="stylesheet">
        <link href="/assets/css/style.css" rel="stylesheet">

    </head>